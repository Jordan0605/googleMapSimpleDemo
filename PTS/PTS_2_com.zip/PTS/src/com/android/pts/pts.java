package com.android.pts;

import java.util.ArrayList;
import java.util.List;
import android.app.Activity;
import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

public class pts extends ListActivity {
	
	private SensorManager smgr;
	List<Sensor> slist;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.main);
        
        smgr = (SensorManager)getSystemService(Context.SENSOR_SERVICE);
        slist = smgr.getSensorList(Sensor.TYPE_ALL);
        ArrayList<String> snlist = new ArrayList<String>();
        
        for (int i = 0; i < slist.size(); i++) {
        	snlist.add(slist.get(i).getName());
        }
        
        ListAdapter adapter = new ArrayAdapter<String>(this,
        	R.layout.list_item, snlist);
        setListAdapter(adapter);
    }
    protected void onListItemClick(ListView l, View v, int position, long id) {
    	super.onListItemClick(l, v, position, id);
    	Intent intent = new Intent(this, SensorReader.class);
    	intent.putExtra("KEY_TYPE", slist.get(position).getType());
    	startActivity(intent);
    }
}